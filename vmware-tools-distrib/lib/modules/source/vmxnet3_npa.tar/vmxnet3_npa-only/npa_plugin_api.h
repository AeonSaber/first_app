/*********************************************************
 * Copyright (C) 2009-2010 VMware, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation version 2 and no later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 *
 *********************************************************/

#ifndef _PLUGIN_API_H
#define _PLUGIN_API_H

#include "npa_defs.h"
#include "npa_shell_api.h"

typedef
#include "vmware_pack_begin.h"
struct Plugin_RxQueueState {
   struct Shell_RxQueueHandle *handle;
   uint8   *ringBaseVA;
   uint64   ringBasePA;
   uint32   ringLength;   /* length in bytes */
   uint32   ringSize;     /* # of descriptors/pkts */
   uint8    *miscInfo;    /* ignore by hw plugin */
}
#include "vmware_pack_end.h"
Plugin_RxQueueState;

typedef
#include "vmware_pack_begin.h"
struct Plugin_TxQueueState {
   struct Shell_TxQueueHandle *handle;
   uint8   *ringBaseVA;
   uint64   ringBasePA;
   uint32   ringLength;   /* length in bytes */
   uint32   ringSize;     /* # of descriptors/pkts */
}
#include "vmware_pack_end.h"
Plugin_TxQueueState;

#define PLUGIN_MAX_RX_QUEUES     16  /* from vmxnet3_defs.h */
#define PLUGIN_MAX_TX_QUEUES     8

/* For non-TSO sends, the Maximum number of buffers to use */
#define PLUGIN_MAX_NONTSO_SG_ELEMENTS  10

#define PLUGIN_SHADOW_ALLOCATION_MULTIPLE  4 /* value 'ringOffset' range: [0, 4x the # descriptors) */

/*
 * Shared area size calculation (current overly-generous draft):
 *
 * bytes allocated per ring = (num[Rx|Tx]Desc * RINGPLUGIN_[RX|TX]_DESC_SIZE_BYTES) +
 *                            (RINGPLUGIN_SHARED_AREA_[RX|TX]_ALLOCATION_ALIGN - 1)
 * bytes allocated for all rings = bytes allocated per ring *
 *                                 RINGPLUGIN_SHARED_AREA_[RX|TX]_ALLOCATION_MULTIPLE
 * total bytes allocated = bytes allocated for all rings +
 *                         RINGPLUGIN_SHARED_AREA_[RX|TX]_EXTRA_ALLOCATION
 */

#define PLUGIN_SHARED_AREA_TX_ALLOCATION_ALIGN     512 /* 512-byte alignment for each ring */
#define PLUGIN_SHARED_AREA_TX_ALLOCATION_MULTIPLE    4 /* # of rings to allocate space for */
#define PLUGIN_SHARED_AREA_TX_MAX_DESC_SIZE_BYTES   16 /* bytes allocated per desciptor */
#define PLUGIN_SHARED_AREA_TX_EXTRA_ALLOCATION    4096 /* add 4K extra bytes */

#define PLUGIN_SHARED_AREA_RX_ALLOCATION_ALIGN     512 /* 512-byte alignment for each ring */
#define PLUGIN_SHARED_AREA_RX_ALLOCATION_MULTIPLE    4 /* # of rings to allocate space for */
#define PLUGIN_SHARED_AREA_RX_MAX_DESC_SIZE_BYTES   16 /* bytes allocated per desciptor */
#define PLUGIN_SHARED_AREA_RX_EXTRA_ALLOCATION    4096 /* add 4K extra bytes */

#define PLUGIN_FEATURES_LRO   0x00000001

typedef
#include "vmware_pack_begin.h"
struct Plugin_State {
   uint32               size;
   uint32               majorVersion;
   uint32               minorVersion;
   uint32               offsetToPrivateSpace;
   uint32               features;
   uint32               mtu;
   uint32               deviceInfo[VMXNET3_PLUGIN_INFO_LEN];
   void                *memioAddr;
   uint32               memioAddrLen;
   uint32               numRxQueues;
   uint32               numTxQueues;
   uint8                updateRxProd;
   uint8                _pad1[3];
   Plugin_RxQueueState  rxQueues[PLUGIN_MAX_RX_QUEUES];
   Plugin_TxQueueState  txQueues[PLUGIN_MAX_TX_QUEUES];
   void                *shared;
   uint32               sharedLen;
   uint32               _pad2;
   Shell_Api            shellApi;
   uint64               privateSpace[1024];
}
#include "vmware_pack_end.h"
Plugin_State;

#ifndef INLINE
#ifdef _WIN32
#define INLINE __inline
#else
#define INLINE inline
#endif
#endif

#if defined(__i386__)
#ifdef _MSC_VER
/*
 * Windows is usually stdcall, so let's force it to be cdecl.
 */
#define PLUGIN_ABI SHELL_ABI
#else /* non MSC compiler (gcc) */
/*
 * Linux is usually cdecl, however it may be compiled with -mregparm=3.
 * Let's overwrite it to pass all arguments on the stack.
 */
#define PLUGIN_ABI SHELL_ABI
#endif
#elif defined(__x86_64__)
/*
 * Nothing special for x64. In the Windows shell we do parameters
 * translation explicitely.
 */
#define PLUGIN_ABI
#else
#error "Cannot detect bitness"
#endif

static INLINE void*
PLUGIN_PRIVATE(Plugin_State *plugin)
{
   return (uint8 *)plugin + plugin->offsetToPrivateSpace;
}

typedef
#include "vmware_pack_begin.h"
struct Plugin_SendInfo {
   uint32   ipHeaderOffset; // valid if 'ipv4' or 'ipv6'
   uint32   l4HeaderOffset; // valid if 'ipv4' or 'ipv6'
   uint32   l4DataOffset;   // valid if ('ipv4' or 'ipv6') and ('tcp' or 'udp')
   uint32   tsoMss;         // valid if 'tso' is set
   Bool     ipv4;
   Bool     ipv6;
   Bool     tcp;
   Bool     udp;
   Bool     tso;
   Bool     xsumTcpOrUdp;  // valid if 'tcp' or 'udp'
   Bool     vlan;
   uint8    _pad1;
   uint16   vlanTag;       // vlan id+priority bits; valid if 'vlan' is set
   uint16   _pad2[3];
}
#include "vmware_pack_end.h"
Plugin_SendInfo;

typedef
#include "vmware_pack_begin.h"
struct Plugin_SgElement {
   uint64   pa;
   uint32   length;
   uint32   _pad;
}
#include "vmware_pack_end.h"
Plugin_SgElement;

/*
 * If IPv4 or IPv6 then headers are contiguous in
 * first SG, up to 128-bytes.  TSO frames, and only TSO frames,
 * are contiguous beyond 128 bytes (on Linux model is TBD).
 * XXX: non-IP frames have at least Ethernet header in first
 * descriptor, or no assumptions can be made in this case?
 */

typedef
#include "vmware_pack_begin.h"
struct Plugin_SgList {
   uint32 totalLength;
   uint32 numElements;
   uint8 *firstSgVA;
   struct Plugin_SgElement *elements;
}
#include "vmware_pack_end.h"
Plugin_SgList;


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_SwInit --
 *
 *    Initialize the s/w state of the plugin. The h/w should not be initialized
 *    through this function. This function is called before any other plugin API
 *    is called by the shell (except for api exchange function).
 *
 *    called during: device/plugin init.
 *    concurrent with: nothing
 *    caller provides: info about configuration and environment
 *    callee performs: verify data provided by shell
 *                     init private state (e.g. head/tail pointers, location of rings)
 *    callee can call: nothing.  callee should not touch hardware and accesses to
 *                     shared memory should be avoided.
 * Result:
 *    0 for success; non-zero for failure
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_SwInit)(Plugin_State *plugin);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_ReinitRxRing --
 *
 *    Initialize the rx ring data structures
 *
 *    called during: device/plugin init.
 *                   device halt
 *                   during a reset (e.g., RSS change, or OS request)
 *    concurrent with: nothing.  Function is called only while device is quiesced and
 *                     the queue is known to be empty.
 *    caller provides: state and queue #
 *    callee performs: bzero rings and reinit head/tail pointers/registers
 *                     should not return any buffers that are found, and assume have
 *                     already been garbage collected.
 *    callee can call: nothing.  callee can write to, but not read from,
 *                     registers and/or memory.
 *
 *  Result:
 *    zero (essentially void)
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_ReinitRxRing)(Plugin_State *plugin,
                                                uint32 queue);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_ReinitTxRing --
 *
 *    Initialize the tx ring data structures
 *
 *    called during: device/plugin init.
 *                   device halt
 *                   during a reset (e.g., RSS change, or OS request)
 *    concurrent with: nothing.  Function is called only while device is quiesced and
 *                     the queue is known to be empty.
 *    caller provides: state and queue #
 *    callee performs: bzero rings and reinit head/tail pointers/registers
 *                     should not complete any sends, and assume have
 *                     already been garbage collected.
 *    callee can call: nothing.  callee can write to, but not read from,
 *                     registers and/or memory.
 *
 *  Result:
 *    zero (essentially void)
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_ReinitTxRing)(Plugin_State *plugin,
                                                uint32 queue);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_EnableInterrupt --
 *
 *    Enable the interrupt indicated by 'intrIdx'
 *
 *    called during: device/plugin init.
 *                   ISR/DPC, to enable interrupts
 *                   OS request (including PM)
 *                   during a reset (e.g., RSS change, or OS request)
 *    concurrent with: Plugin_AddBuffersToRxRing()
 *                     Plugin_CheckRxRing()
 *                     Plugin_AddFrameToTxRing()
 *                     Plugin_CheckTxRing()
 *                     Plugin_DisableInterrupt()
 *    caller provides: state and vector # (note is not queue #)
 *    callee performs: enable interrupt for vector
 *    callee can call: nothing
 *
 * Result:
 *    zero (essentially void)
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_EnableInterrupt)(Plugin_State *plugin,
                                                   uint32 intrIdx);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_DisableInterrupt --
 *
 *    Disable the interrupt indicated by 'intrIdx'
 *
 *    called during: ISR to disable interrupts
 *                   OS request (including PM)
 *                   during a reset (e.g., RSS change, or OS request)
 *                   halt / shutdown
 *    concurrent with: Plugin_AddBuffersToRxRing()
 *                     Plugin_CheckRxRing()
 *                     Plugin_AddFrameToTxRing()
 *                     Plugin_CheckTxRing()
 *                     Plugin_EnableInterrupt()
 *    caller provides: state and vector # (note is not queue #)
 *    callee performs: disalbe interrupt for vector
 *    callee can call: nothing
 *
 * Result:
 *    zero (essentially void)
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_DisableInterrupt)(Plugin_State *plugin,
                                                    uint32 intrIdx);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_AddFrameToTxRing --
 *
 *    Add the frame made up of buffers in the sg list 'frame' to the hardware tx
 *    ring of the given queue. The offload information is passed in 'info'.
 *    'lastPktHint' is used to indicate that no more tx packets would be passed
 *    down in this context and the plugin should use this as a hint to write to
 *    the h/w doorbell.
 *
 *    called during: ISR/DPC, after ring check
 *                   OS transmit issued for a frame
 *    concurrent with: Plugin_CheckTxRing()
 *                     Plugin_EnableInterrupt()
 *                     Plugin_DisableInterrupt()
 *    caller provides: state and queue #
 *                     information about frame (including frame type and header offsets)
 *                     SG array of frame buffers, all eth/ip/tcp/udp headers in first SG
 *    callee performs: attempt to add frame to tx ring
 *                     TBD: touch device registers, if applicable (TBD how/when for vmxnet3)
 *    callee can call: nothing
 *
 * Result:
 *    0 if successful, 1 to indicate no space in h/w tx ring
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_AddFrameToTxRing)(Plugin_State *plugin,
                                                    uint32 queue,
                                                    const Plugin_SendInfo *info,
                                                    const Plugin_SgList *frame,
                                                    Bool lastPktHint);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_CheckTxRing --
 *
 *    Check the tx ring for the given queue for any tx completions.
 *    This call is made by the shell either during the interrupt or DPC/napi
 *    context.
 *
 *    called during: ISR/DPC
 *    concurrent with: Plugin_AddFrameToTxRing()
 *                     Plugin_EnableInterrupt()
 *                     Plugin_DisableInterrupt()
 *    caller provides: state and queue #
 *    callee performs: checks ring for any completed sends, and returns them
 *    callee can call: Shell_CompleteSend()
 *
 * Result:
 *    zero (essentially void)
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_CheckTxRing)(Plugin_State *plugin,
                                               uint32 queue);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_CheckRxRing --
 *
 *    Check the rx ring for any incoming packets on the given queue.
 *    'maxPkts' indicate the maximum number of packets the plugin can indicate
 *    upto the shell in this context. The shell calls this function during the
 *    interrupt or DPC/napi context.
 *
 *    called during: ISR/DPC
 *    concurrent with: Plugin_AddBuffersToRxRing()
 *                     Plugin_EnableInterrupt()
 *                     Plugin_DisableInterrupt()
 *    caller provides: state and queue #
 *                     max # of frames to indicate in one call
 *    callee performs: checks ring for any receives, and indicates them up.
 *                     Callee can/should indicate up frames with bad checksums,
 *                     but should not indicate runts, truncated frames, bad CRCs,
 *                     or other types of bad frames.
 *    callee can call: Shell_IndicateRecv()
 *                     Shell_FreeBuffer()
 *
 * Result:
 *    1 to indicate need for buffers, 0 for no need for buffers.
 *
 * Side-effects:
 *    Packets are indicated up and delivered to the OS stack during this call.
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_CheckRxRing)(Plugin_State *plugin,
                                               uint32 queue,
                                               uint32 maxPkts);


/*
 *----------------------------------------------------------------------------
 *
 * Plugin_AddBuffersToRxRing --
 *
 *    The plugin can make calls to the shell to allocate more buffers. This call
 *    is made during the plugin initialization or after Plugin_CheckRxRing or
 *    when the OS stack returns buffers back to the shell. The plugin should try
 *    to allocate as many buffers as needed to fill the h/w rings.
 *
 *    called during: device/plugin init.
 *                   ISR/DPC, after Plugin_CheckRxRing()
 *                   OS returns buffers (if applicable for OS)
 *    concurrent with: Plugin_CheckRxRing()
 *                     Plugin_EnableInterrupt()
 *                     Plugin_DisableInterrupt()
 *    caller provides: state and queue #
 *    callee performs: add empty buffers to rx ring(s), as much as possible
 *                     touch device registers, if applicable
 *    callee can call: Shell_AllocSmallBuffer()
 *                     Shell_AllocLargeBuffer()
 *                     Shell_FreeBuffer()
 *
 * Result:
 *    zero (essentially void)
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI Plugin_AddBuffersToRxRing)(Plugin_State *plugin,
                                                      uint32 queue);

typedef struct
#include "vmware_pack_begin.h"
Plugin_Api {
   Plugin_SwInit              *swInit;
   Plugin_ReinitRxRing        *reinitRxRing;
   Plugin_ReinitTxRing        *reinitTxRing;
   Plugin_EnableInterrupt     *enableInterrupt;
   Plugin_DisableInterrupt    *disableInterrupt;
   Plugin_AddFrameToTxRing    *addFrameToTxRing;
   Plugin_CheckTxRing         *checkTxRing;
   Plugin_CheckRxRing         *checkRxRing;
   Plugin_AddBuffersToRxRing  *addBuffersToRxRing;
}
#include "vmware_pack_end.h"
Plugin_Api;

/*
 *----------------------------------------------------------------------------
 *
 * NPA_PluginMain --
 *
 *    This is the first function that the shell calls into the plugin and is
 *    used to obtain the plugin API function pointer for further communication.
 *
 * Result:
 *    Plugin_Api function table filled with the plugin api functions.
 *
 * Side-effects:
 *    None
 *
 *----------------------------------------------------------------------------
 */

typedef uint32 (PLUGIN_ABI *NPA_PluginMainFunc)(struct Plugin_Api *pluginApi);

#endif // _PLUGIN_API_H
